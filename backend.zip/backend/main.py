from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel
from typing import List,Annotated
import newmodels
from newdatabase import engine,SessionLocal
from sqlalchemy.orm import Session
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()
origins=['http://localhost:3000']
newmodels.Base.metadata.create_all(bind=engine)

app.add_middleware(
CORSMiddleware,
allow_origins=origins,
allow_credentials=True,
allow_methods=['*'],
allow_headers=['*']
)

class BookBase(BaseModel):
  book_name:str
  book_price:float
  class Config:
    orm_mode=True
  

def get_db():
  db=SessionLocal()
  try:
    yield db
  finally:
     db.close() 	

db_dependency=Annotated[Session,Depends(get_db)]

@app.get("/books/{book_id}")
async def read_book(book_id:int,db:db_dependency):
  result=db.query(newmodels.Books).filter(newmodels.Books.id==book_id).first()
  if not result:
    raise HTTPException(status_code=404,details='Book is not found')
  return result

@app.get("/books")
async def read_book(db:db_dependency):
  result=db.query(newmodels.Books).order_by('id').all()
  if not result:
    raise HTTPException(status_code=404,details='Book is not found')
  return result


@app.post("/book/")
async def create_book(book:BookBase,db:db_dependency):
   db_book=newmodels.Books(book_name=book.book_name,book_price=book.book_price)
   db.add(db_book)
   db.commit()
   db.refresh(db_book)
  
 